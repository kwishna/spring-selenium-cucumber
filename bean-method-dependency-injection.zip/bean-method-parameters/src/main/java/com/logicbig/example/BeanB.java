package com.logicbig.example;

public class BeanB {
    private BeanA beanA;

    BeanB (BeanA beanA) {
        this.beanA = beanA;
    }

    public BeanA getBeanA () {
        return beanA;
    }

    @Override
    public String toString() {
        return "BeanB{" +
                "beanA=" + beanA +
                '}';
    }
}