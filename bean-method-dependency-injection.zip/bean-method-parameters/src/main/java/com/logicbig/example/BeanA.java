package com.logicbig.example;

public class BeanA {
    private String name;

    public BeanA(String name){
        this.name = name;
    }

    @Override
    public String toString() {
        return "BeanA{" +
                "name='" + name + '\'' +
                '}';
    }
}