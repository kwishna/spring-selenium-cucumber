package com.logicbig.example;

public class BeanC {
    private String name;

    public BeanC(String name){
        this.name = name;
    }

    @Override
    public String toString() {
        return "BeanC{" +
                "name='" + name + '\'' +
                '}';
    }
}