package com.swtestacademy.springbootselenium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication()
public class SpringSeleniumApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringSeleniumApplication.class, args);
	}
}
