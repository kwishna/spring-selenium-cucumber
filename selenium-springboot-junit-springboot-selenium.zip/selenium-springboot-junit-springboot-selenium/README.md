# selenium-springboot
Selenium and Spring Boot test automation example.
